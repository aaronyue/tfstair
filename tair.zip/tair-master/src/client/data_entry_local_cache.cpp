#include "data_entry_local_cache.h"

using namespace std;

namespace tair 
{

void data_entry_local_cache_instantiation()
{
  data_entry_local_cache var(0);
}

}

